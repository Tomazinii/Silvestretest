var x = document.getElementsByClassName("gLFyf").innerText;


function getVal() {
	const val = document.querySelector('input').value;
	console.log(val);
  }

